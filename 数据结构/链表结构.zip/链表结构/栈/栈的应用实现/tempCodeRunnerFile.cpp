    if (braketCheck(str, length))
