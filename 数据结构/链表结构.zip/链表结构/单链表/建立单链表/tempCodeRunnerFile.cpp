    if (p == NULL)
    {
        /* code */
        return NULL;
    }