    // if (chars[0] == NULL)
    // {
    //     /* code */
    //     // printf("%s", chars[0]);
    //     return false;
    // }
